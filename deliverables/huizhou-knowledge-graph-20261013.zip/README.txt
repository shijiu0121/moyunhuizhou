徽史问答官知识图谱增量包 · 2026-10-13

请先阅读 docs/知识图谱交付说明.md。
backend/、frontend/、docs/ 按项目相对路径组织。
完整文件覆盖或 changes.patch 两种方式只选一种。
无需重新安装依赖，无需更新模型或重建向量库。
保留服务器现有 .env、app/data 原文、models 和 vector_store。
本地 60 篇知识资料生成 70 个节点、37 组关联。
新增页面 /ask/knowledge；新增接口 /api/ask/knowledge-graph。
包内不包含知识原文、密钥、模型、依赖或 dist。
同步后重启后端；静态部署需重新 npm run build。
